#include "SpriteManager.h"

namespace {
const QPixmap& emptyPixmap()
{
    // QPixmap requires a QGuiApplication. This function is only called at runtime
    // (after QApplication is constructed), avoiding static initialization crashes.
    static QPixmap empty;
    return empty;
}
} // namespace

const QPixmap& SpriteManager::sprite(const QString& key) const
{
    const auto it = m_cache.constFind(key);
    if (it == m_cache.constEnd()) {
        return emptyPixmap();
    }
    return it.value();
}

void SpriteManager::load(const QString& key, const QString& filePath)
{
    QPixmap pix(filePath);
    m_cache.insert(key, pix);
}

void SpriteManager::clear()
{
    m_cache.clear();
}

