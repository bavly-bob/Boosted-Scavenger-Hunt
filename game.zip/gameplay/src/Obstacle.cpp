﻿#include "Obstacle.h"

